# WebStudio OS Local

Один файл index.html. Данные хранятся только в браузере (IndexedDB), на GitHub они не попадают.
